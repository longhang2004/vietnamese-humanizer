# Register tiếng Việt

Tách độ trang trọng khỏi kênh và quan hệ: email có thể thân mật, chat có thể trang trọng. "Giữ giọng gốc" là mặc định; chỉ chuyển giọng khi người dùng yêu cầu. Với xưng hô, ghi rõ người gửi, người nhận và cặp đã thống nhất thay vì suy từ chức danh hoặc tên.

## Kỹ thuật

Ưu tiên độ chính xác, chủ thể rõ và thuật ngữ nhất quán. Câu bị động vẫn hợp lý khi quy trình quan trọng hơn người thao tác. Giữ nguyên code, API, command, path và identifier.

## Công việc

Nêu việc cần làm, người phụ trách và hạn chót. Lịch sự không cần nhiều lớp rào đón. Cách xưng hô phụ thuộc quan hệ tổ chức; không tự đổi "anh/chị" thành "bạn".

## Học thuật

Giữ hedge, giới hạn, trích dẫn và thuật ngữ. Không thêm giọng cá nhân nếu ngành hoặc bài viết không dùng giọng đó. Danh hóa không tự động là lỗi.

## Marketing và sản phẩm

Cho phép ngôn ngữ thuyết phục nếu có căn cứ. Thay lời khen chung chung bằng lợi ích hoặc bằng chứng đã có. Không tạo số liệu hay phản hồi khách hàng.

## Chăm sóc khách hàng

Thừa nhận vấn đề vừa đủ, rồi nêu trạng thái và bước tiếp theo. Không thêm cảm xúc kịch tính, hứa quá thẩm quyền hoặc đổi "quý khách" sang giọng thân mật.

## Mạng xã hội và blog

Có thể giữ nhịp lệch, khẩu ngữ, câu ngắn và tiếng địa phương nếu đó là giọng thật. Không "chuẩn hóa" thành văn bản doanh nghiệp.

## Văn viết gần gũi và hội thoại

Văn viết gần gũi ưu tiên cách giải thích dễ theo nhưng vẫn có đoạn và mạch ý đầy đủ. Chat cần xét lượt trước, quan hệ và hành động tiếp theo. Kịch bản nói cần kiểm tra khả năng nghe hiểu sau một lượt. Tra [hướng dẫn theo kênh](conversational.md) khi người dùng chọn chat hoặc kịch bản nói; không dùng tiểu từ cuối câu để thay cho quyết định về quan hệ.

## Hành chính, pháp lý và chính sách

Ưu tiên chính xác hơn tự nhiên. Giữ định nghĩa, phạm vi, điều kiện, từ chỉ nghĩa vụ và cấu trúc liệt kê có chức năng pháp lý. Chỉ sửa khi chắc rằng hiệu lực không đổi.
