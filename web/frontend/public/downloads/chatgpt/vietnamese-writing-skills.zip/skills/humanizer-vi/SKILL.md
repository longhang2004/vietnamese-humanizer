---
name: humanizer-vi
description: Sửa câu sáo rỗng, máy móc hoặc lệch giọng để bài viết rõ và tự nhiên
  hơn. Giữ dữ kiện và giọng tác giả; dùng để biên tập, không để đoán ai viết.
license: MIT
metadata:
  language: vi
  version: 0.5.0
---

# Humanizer tiếng Việt

Biên tập chất lượng viết, không phân loại nguồn gốc văn bản. Một tín hiệu đơn lẻ không đủ để kết luận có vấn đề. Ưu tiên cụm tín hiệu, tác động thật lên người đọc và mục đích của văn bản.

## Quy trình

1. Xác định loại văn bản, độc giả, mục đích và register. Nếu thiếu dữ kiện, suy ra từ văn bản và chọn mức can thiệp thấp.
2. Ghi nhận giọng hiện có: cách xưng hô, độ dài câu, mức trực tiếp, thuật ngữ và thói quen trình bày.
3. Đọc toàn đoạn trước khi sửa. Đánh dấu cấu trúc lặp, ý trừu tượng thiếu thông tin, lời dẫn chung chung, nhịp quá đều, giọng quảng cáo lệch ngữ cảnh và phần giải thích chen ngang việc người đọc đang làm.
4. Sửa cấu trúc câu và đoạn trước khi thay từ. Nêu hành động hoặc quan hệ logic trực tiếp; gộp hay tách câu khi giúp người đọc theo ý.
5. Giữ những câu đã ổn. Không sửa một cụm chỉ vì nó có trong catalog.
6. Rà lại đại từ, thuật ngữ và register. Đọc thành tiếng nếu nhịp câu là vấn đề.
7. Đọc bản sửa như người nhận. Trong bài kể, kiểm ai đang làm hoặc đang nhớ. Trong hướng dẫn, kiểm người đọc nhận ra dấu hiệu được đi tiếp ngay ở bước liên quan. Đối chiếu bản gốc để giữ đúng nghĩa. Chỉ giải thích thay đổi khi người dùng yêu cầu.

Đọc [workflow chi tiết](references/workflow.md) cho văn bản dài hoặc khi nhiều pattern chồng nhau. Tra [register](references/registers.md) trước khi sửa văn bản học thuật, pháp lý, hành chính hay chăm sóc khách hàng.

Đọc [diễn đạt tự nhiên](references/naturalness.md) khi chỉnh văn phong: tài liệu này hướng dẫn kết hợp từ, mạch thông tin, phép lặp và sắc thái. Chỉ đọc [hội thoại và kịch bản nói](references/conversational.md) khi người dùng chọn các kênh đó; văn viết gần gũi vẫn có tiêu chí riêng.

Viết theo việc người đọc đang cần. Chỉ thêm định nghĩa, lời hướng dẫn, lưu ý hoặc câu phân biệt khi chúng giải quyết một vướng mắc cụ thể ở vị trí đó. Đừng tự biến mọi đoạn thành bài hướng dẫn hoặc mang các lưu ý nội bộ của skill vào bản sửa. Xem phần giải thích đúng lúc trong [diễn đạt tự nhiên](references/naturalness.md); giữ điều kiện, cảnh báo và phép đối chiếu có tác dụng thật.

Khi bài lặp đối lập, câu tự nhấn mạnh, nhịp giật ngắn, tiêu đề/bullet hoặc kết đoạn tóm lại, đọc [sửa lối viết theo khuôn](references/formulaic-prose.md). Sửa theo chức năng và mật độ trong ngữ cảnh; giữ cấu trúc có tác dụng, khoảng số, thuật ngữ và giọng riêng. Không dùng danh sách “AI tells” để suy đoán tác giả hoặc làm từ điển thay thế.

Khi người dùng chọn loại bài viết, đọc [writing profiles](references/writing-profiles.md) rồi chỉ đọc reference phù hợp: [văn viết rõ ràng](references/plain-writing.md), [trao đổi công việc](references/business-writing.md), [tài liệu kỹ thuật](references/technical-writing.md), [hành chính](references/administrative-writing.md), [bài đăng mạng xã hội](references/social-writing.md) hoặc [marketing](references/marketing-writing.md). Profile không tự đổi giọng, kênh, xưng hô hay mức can thiệp; mặc định giữ loại bài gốc.

## Ngữ cảnh và quyền biên tập

Phân biệt kênh (tài liệu, email, chat, kịch bản nói), độc giả, quan hệ giao tiếp, xưng hô và độ trang trọng. Chọn kênh chat không có nghĩa được đổi "tôi" thành "em" hoặc thêm "ạ". Khi thiếu thông tin, giữ giọng và xưng hô hiện có.

Mặc định sửa nhẹ. Chỉ sắp xếp lại đoạn khi người dùng cho phép can thiệp sâu; mọi mức đều phải giữ nội dung. Khi được yêu cầu giảm cường điệu (`reduce_hype=true` trong ứng dụng), có thể giảm tính từ quảng cáo hoặc đồng cảm công thức. Quyền này không cho phép đổi số, phạm vi, mức chắc chắn, nghĩa vụ hay lập trường tích cực thành tiêu cực. Nếu bỏ một nhận định sẽ đổi thông điệp, góp ý để tác giả quyết định.

## Bảo toàn

Giữ nguyên dữ kiện, con số, tên riêng, trích dẫn, điều kiện, ngoại lệ, lập trường, thuật ngữ và mức độ chắc chắn. Không đổi "có thể" thành "sẽ", không xóa giới hạn nghiên cứu và không thêm ví dụ để làm câu sinh động.

Trong báo cáo và bài nghiên cứu, giữ mốc chốt, phạm vi, điều kiện đo và nguồn đủ gần kết quả. Giữ đúng nghĩa của “ước tính”, “trong mô phỏng”, “người tham gia cho biết” và “chưa phát hiện”. Phân biệt kết quả ghi nhận, diễn giải, kiến nghị và việc dự kiến. Khi bằng chứng chỉ nêu mối liên hệ, giữ đúng mức đó. Xem phần báo cáo và nghiên cứu trong [tài liệu kỹ thuật](references/technical-writing.md) khi cần rà sâu.

Chỉ dùng thông tin ngoài đoạn input khi nó được cung cấp rõ trong context. Không viện dẫn “chi tiết đã có trong bài” nếu phần bài đó không có trong dữ liệu đang review.

Khi một câu mơ hồ theo nhiều cách hợp lý, giữ nguyên phần mơ hồ hoặc hỏi lại nếu cách hiểu làm thay đổi kết quả đáng kể. Dùng checklist đầy đủ trong [preservation rules](references/preservation-rules.md).

## Cách chọn pattern

- Ưu tiên pattern làm mất thông tin hoặc làm sai register.
- Với từ nối, lời mở đầu, danh sách ba ý và nhịp câu, xét mật độ trên cả đoạn.
- Với lời dẫn nguồn mơ hồ, không tự bịa nguồn thay thế hoặc âm thầm hạ mức chắc chắn. Góp ý về bằng chứng còn thiếu; chỉ thu hẹp tuyên bố khi tác giả cho phép và context đủ căn cứ.
- Với giọng cá nhân, chỉ giữ hay tăng cá tính khi văn bản gốc đã có cơ sở. Văn bản trung lập không cần thêm "tôi".
- Nếu đầu vào tự nhiên và phù hợp, trả lại gần như nguyên văn.

Danh mục giải thích nằm ở [patterns](references/patterns.md). Xem [examples](references/examples.md) để phân biệt sửa hợp lý với over-editing.

## Anti-goals

- Không tuyên bố đoạn văn do AI viết hoặc chấm "xác suất AI".
- Không hỗ trợ vượt detector, thêm lỗi, tiếng lóng hay chi tiết giả.
- Không áp một giọng thân mật cho mọi văn bản.
- Không làm phẳng khác biệt vùng miền, thế hệ hoặc nghề nghiệp.
- Không rút gọn nội dung quan trọng chỉ để câu ngắn hơn.
- Không thay từ đồng nghĩa hàng loạt khi cấu trúc mới là vấn đề.
- Không biến nội dung kỹ thuật, học thuật hoặc pháp lý thành bản quảng cáo.

## Cách chọn mức can thiệp

Không mặc định mọi câu có tín hiệu đều phải sửa. Chọn một mức:

- **Giữ nguyên**: câu đã đúng nghĩa và register, hoặc tín hiệu catalog không đủ chắc.
- **Viết lại**: có thể sửa cấu trúc hoặc lỗi mà không đổi dữ kiện, lập trường hay thuật ngữ.
- **Góp ý**: cần người viết xem lại; nêu vị trí và lựa chọn, đừng tự đoán.
- **Cần tác giả quyết định**: xưng hô, glossary, hoặc cách hiểu làm đổi nghĩa.

## Đầu ra

Khi đã có thể biên tập an toàn, mặc định chỉ trả bản đã biên tập. Nếu cần kiểm chứng hoặc tác giả quyết định trước, chỉ trả nhận xét/câu hỏi cần giải quyết; chờ xác nhận rồi mới đưa bản thay thế. Không thêm lời dẫn như “Dưới đây là phiên bản…” hay “Nếu bạn cần, tôi có thể…”. Khi người dùng yêu cầu review, dùng [review template](assets/review-template.md) và [rubric](references/evaluation.md). Không gắn nhãn chắc chắn cho tác giả hay nguồn gốc văn bản.
